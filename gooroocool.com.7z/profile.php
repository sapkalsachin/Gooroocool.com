
<html>
    <head>

        <title><?php echo $title; ?></title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
            <link href="css/custom.css" rel="stylesheet">
            <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">  
    </head>
    
    <body class="container background" style="overflow-x:hidden">
            <div class="">
                <div class="row">
                    <div class="col-md-3 userinfo">
                        <div class="row">
                            <div class="col-sm-12 col-md-12">
                                <center>
                                    <img class="photo" src="img/backgrounds/bg02.jpg">
                                </center>
                                
                                <center><h2> Name Surname</h2></center>
                            

                            </div>
                        </div>
                        <br>
                        <div class="clearfix">
                            <br>
                        </div>

                        <div class="col-sm-12 col-md-12 details">
                            <hr/>
                            <div class="status">
                                
                            </div>
                            <div class="">
                                
                            </div>
                        </div>

                    </div>

                    <div class="col-md-9 activities">
                        <div class="col-md-11 col-sm-11 recent_posts">
                            <div class="container">
                                <h1>Recent posts</h1>
                                <hr>
                            </div>
                            <div class="col-md-12 col-sm-12"><p class="posts col-xs-12">Ljhcjdnfndsc dhfdfd udfhdufh fud fudfh dufhdufsd
                            d fdfdfdjfh dffhdfdf
                            hbdhdsfsd hfdhfdkjhfdkhkjhdudyeu fhfeuhe
                            fefefgdjfhgbyedgey gdhashdewded
                            dwegddgydg ygdyweddh dhedhkfhasjkfgyef    uduas
                            ehgdygfahsf ydgahsdhasd ehsahnf
                            dasdsa hasgdad hasdhaudhd</p></div>
                        </div>
                        <div class="col-md-1 col-sm-1 navigator"></div>
                    </div>
                </div>
            </div>
    </body></html>